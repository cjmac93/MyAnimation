package com.example.myanimation;

import android.graphics.drawable.AnimationDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button begin = (Button)findViewById(R.id.btnStart);

        begin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView ball= (ImageView)findViewById(R.id.imageView);
                ball.setImageResource(R.drawable.soccerball);
                AnimationDrawable ballA = (AnimationDrawable)ball.getDrawable();
                ballA.start();
            }
        });
    }
}
